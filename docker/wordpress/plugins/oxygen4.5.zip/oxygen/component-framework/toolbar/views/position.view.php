<?php 
include_once("position/position.margin_padding.view.php"); 
include_once("position/position.size.view.php");
?>