<a class='oxy-post' href='<?php the_permalink(); ?>'>
  <div class='oxy-post-background'>
	  <img src='<?php the_post_thumbnail_url(); ?>' class='oxy-post-image' />  
  </div>
  
    <div class='oxy-post-overlay'>
      <h2 class='oxy-post-title'><?php the_title(); ?></h2>
    </div>
</a>